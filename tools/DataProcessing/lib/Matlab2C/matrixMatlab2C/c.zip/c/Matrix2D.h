// #include "Matrix2D.h"
#ifndef MATRIX2D_H
#define MATRIX2D_H

#include "stdlib.h"
#include "stdio.h"
#include "assert.h"
#include "string.h"

// 2D matrix: access (i,j) m.data[i + j*sizeX], 0 <= i < sizeX, 0 <= j < sizeY
typedef struct _Matrix2D {
	int sizeX;
    int sizeY;
    double * data;
} Matrix2D;

// initialize matrix at given size
Matrix2D m2D_init(int sizeX, int sizeY) {
	Matrix2D m;
    m.sizeX = sizeX;
    m.sizeY = sizeY;
    m.data = malloc(sizeX*sizeY*sizeof(double));
    return m;
}

// set value in matrix
inline void m2D_set(Matrix2D m, int i, int j, double val) {
	m.data[i + j*(m.sizeX)] = val;
}

// get value in matrix
inline double m2D_get(const Matrix2D m, int i, int j) {
	return m.data[i + j*(m.sizeX)];
}

// load file
Matrix2D m2D_load(const char* filename) {
	// INIT
    Matrix2D m;
	FILE* outfile;
    outfile = fopen(filename, "r");
    // HEADER
    int header[2];
    fread(header, sizeof(int), 2, outfile);
    if (header[0] != 1234) {
        printf("Magic number did not match. Aborting\n");
        abort();
    }
    if (header[1] != 2) {
        printf("Dimensions of matrix do not match. Aborting\n");
        abort();
    }
    // MATRIX SIZE
    fread(&m.sizeX, sizeof(int), 1, outfile);
    fread(&m.sizeY, sizeof(int), 1, outfile);
    // DATA
    const int nelem = m.sizeX * m.sizeY;
    m.data = malloc(nelem * sizeof(double));
    int data_type;
    fread(&data_type, sizeof(int), 1, outfile);
    if (data_type == 0) {
    	// double
        fread(m.data, sizeof(double), nelem, outfile);
    } else if (data_type == 1) {
    	// float
        float * data = malloc(nelem * sizeof(float));
        fread(data, sizeof(float), nelem, outfile);
        int i; for (i = 0; i < nelem; ++i) m.data[i] = data[i];
    } else if (data_type == 2) {
    	// int
        int * data = malloc(nelem * sizeof(int));
        fread(data, sizeof(int), nelem, outfile);
        int i; for (i = 0; i < nelem; ++i) m.data[i] = data[i];
    } else {
        printf("Don't know type %d. Aborting\n", data_type);
        abort();
    }
    // CLEANUP
    fclose(outfile);
    return m;
}

// dump file
void m2D_dump(const Matrix2D m, const char* filename) {
	// INIT
    FILE* outfile;
    outfile = fopen(filename, "w");
    // HEADER & MATRIX SIZE & DATA-type
    int header[5] = {1234, 2, m.sizeX, m.sizeY, 0};
    fwrite(header, sizeof(int), 5, outfile);
    // DATA
    fwrite(m.data, sizeof(double), m.sizeX * m.sizeY, outfile);
    // CLEANUP
    fclose(outfile);
}

// free up data in matrix
void m2D_free(Matrix2D m) {
    m.sizeX = 0;
    m.sizeY = 0;
	free(m.data);
    m.data = 0;
}

#endif
