#include "stdlib.h"
#include "stdio.h"

#include "Matrix2D.h"

/** Get test matrix for interpolations. */
void fillMatrix(Matrix2D m) {
    // fill it (source wiki bicubic interp.)
    m2D_set(m,0,0,1); m2D_set(m,1,0,2); m2D_set(m,2,0,4); m2D_set(m,3,0,1); m2D_set(m,4,0,1);
    m2D_set(m,0,1,6); m2D_set(m,1,1,3); m2D_set(m,2,1,5); m2D_set(m,3,1,2); m2D_set(m,4,1,4);
    m2D_set(m,0,2,4); m2D_set(m,1,2,2); m2D_set(m,2,2,1); m2D_set(m,3,2,5); m2D_set(m,4,2,4);
    m2D_set(m,0,3,5); m2D_set(m,1,3,4); m2D_set(m,2,3,2); m2D_set(m,3,3,3); m2D_set(m,4,3,4);
    m2D_set(m,0,4,3); m2D_set(m,1,4,3); m2D_set(m,2,4,3); m2D_set(m,3,4,2); m2D_set(m,4,4,3);
}

int main(int argc, char * const argv[]) {
    
    // generate it
    Matrix2D m = m2D_init(5,5);
    fillMatrix(m);
    
    // show matrix
    int i,j;
    for (j = 0; j < m.sizeY; ++j) {
        for (i = 0; i < m.sizeX; ++i) {
            printf("%g", m2D_get(m,i,j));
            if (i < m.sizeX-1) printf(", ");
        }
        printf("\n");
    }
    
    // dump it to file & read
    m2D_dump(m, "matrix.dat");
    Matrix2D m2 = m2D_load("matrix.dat");

    // show matrix m2 (w/o m2D_get...probably irrelevant for smart compilers)
    printf("Showing dumped and reloaded matrix\n");
    for (j = 0; j < m2.sizeY; ++j) {
        for (i = 0; i < m2.sizeX; ++i) {
            printf("%g", m2.data[i + j*(m2.sizeX)]);
            if (i < m2.sizeX-1) printf(", ");
        }
        printf("\n");
    }
    
    m2D_free(m);
    m2D_free(m2);
    
    return 0;
}
